const express = require('express')
const app = express();
import { getUserList } from './user';
const userList = getUserList();

app.get('/users', (req, res) => {return res.status(200).send({
        success : 'true',
        message : 'users',
        users : userList})});

app.get('/', (req, res) => {
res.send('Welcome to learn backend with express!');
});
app.listen(8000, () => {
console.log('Example app listening on port 8000!');
});